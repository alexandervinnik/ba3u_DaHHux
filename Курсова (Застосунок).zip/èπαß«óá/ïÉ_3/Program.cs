﻿using MySql.Data.MySqlClient;
using System;
using System.Data.Common;
using System.Runtime.Remoting.Messaging;
using System.Xml.Linq;

namespace ЛР_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Getting Connection ...");
            MySqlConnection conn = DBUtils.GetDBConnection();

            try
            {
                Console.WriteLine("Openning Connection ...");
                
                conn.Open();

                Console.WriteLine("Connection Succesful!");
                QueryEmployee(conn);
            }

            catch (Exception e) 
            {
                Console.WriteLine("Error: " + e.Message);
                Console.WriteLine(e.StackTrace);
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
            Console.Read();
        }
        private static void QueryEmployee(MySqlConnection conn)
        {
            while (true)
            {
                Console.WriteLine("Головне меню");
                Console.WriteLine("1 - Список клiєнтiв");
                Console.WriteLine("2 - Тарифи путiвок");
                Console.WriteLine("3 - Бронювання кiмнат");
                Console.WriteLine("4 - Список кiмнат");
                Console.WriteLine("5 - Орендований iнвентар");
                Console.WriteLine("6 - Спорт iнвентар для аренди");
                Console.WriteLine("7 - Замовленi послуги");
                Console.WriteLine("8 - Прайс лист послуг");
                Console.WriteLine("9 - Реєстрацiя нового клiєнта");
                Console.WriteLine("10 - Замовлення додаткових послуг");
                Console.WriteLine("11 - Оренда спортивного iнвентаря");
                Console.WriteLine("12 - Вихiд");
                string input = Console.ReadLine();
 
                switch (input)
                {
                    case "1":
                        Console.WriteLine("Таблиця: Cusromers");

                        string id, name, phone, ticket;
                        string sql = "select * from customers;";

                        MySqlCommand cmd = new MySqlCommand();
                        cmd.Connection = conn;
                        cmd.CommandText = sql;

                        using (DbDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    id = reader["Customer_id"].ToString();
                                    name = reader["Name"].ToString();
                                    phone = reader["Phone_num"].ToString();
                                    ticket = reader["Ticket_id"].ToString();
                                    Console.WriteLine("____________________________________________________________________________________");
                                    Console.WriteLine("ID: " + id + " | Им'я: " + name + " | Номер телефона: " + phone + " | Путiвка: " + ticket);
                                    Console.WriteLine("____________________________________________________________________________________");
                                }
                                Console.WriteLine("Головне меню - Enter");
                            }
                        }
                        break;
                    case "2":
      
                        Console.WriteLine("Таблиця: Tickets");
                        string ticket_id, ticket_name, price, days;
                        sql = "select * from tickets;";

                        MySqlCommand cmd1 = new MySqlCommand();
                        cmd1.Connection = conn;
                        cmd1.CommandText = sql;

                        using (DbDataReader reader = cmd1.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    ticket_id = reader["ticket_id"].ToString();
                                    ticket_name = reader["ticket_name"].ToString();
                                    price = reader["ticket_price"].ToString();
                                    days = reader["Ticket_days"].ToString();
                                    Console.WriteLine("_______________________________________________");
                                    Console.WriteLine("ID: " + ticket_id + " | Назва: " + ticket_name + " | Цiна: " + price + " | Днi: " + days);
                                    Console.WriteLine("_______________________________________________");
                                }
                                Console.WriteLine("Головне меню - Enter");
                            }
                        }
                        break;
                    case "3":

                        Console.WriteLine("Таблиця: Hotel");
                        string room_order_id, Customer_id, liv_date, room;
                        sql = "select * from hotel;";

                        MySqlCommand cmd2 = new MySqlCommand();
                        cmd2.Connection = conn;
                        cmd2.CommandText = sql;

                        using (DbDataReader reader = cmd2.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    room_order_id = reader["room_order_id"].ToString();
                                    Customer_id = reader["Customer_id"].ToString();
                                    liv_date = reader["start_living"].ToString();
                                    room = reader["Room_id"].ToString();
                                    Console.WriteLine("__________________________________________________________________________");
                                    Console.WriteLine("ID: " + room_order_id + " | Клiєнт: " + Customer_id + " | Початок проживання: " + liv_date + " | Кiмната: " + room);
                                    Console.WriteLine("__________________________________________________________________________");
                                }
                                Console.WriteLine("Головне меню - Enter");
                            }
                        }
                        break;
                    case "4":

                        Console.WriteLine("Таблиця: Rooms");
                        string room_id, beds_col;
                        sql = "select * from rooms;";

                        MySqlCommand cmd3 = new MySqlCommand();
                        cmd3.Connection = conn;
                        cmd3.CommandText = sql;

                        using (DbDataReader reader = cmd3.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    room_id = reader["room_id"].ToString();
                                    beds_col = reader["beds_col"].ToString();
                                    Console.WriteLine("_________________________________");
                                    Console.WriteLine("Кiмната: " + room_id + " | Кiлькiсть лiжок: " + beds_col);
                                    Console.WriteLine("_________________________________");
                                }
                                Console.WriteLine("Головне меню - Enter");
                            }
                        }
                        break;
                    case "5":

                        Console.WriteLine("Таблиця: Equip_rental");
                        string rental_id, Equip_id, Customer_rent_id, Rental_date;
                        sql = "select * from Equip_rental;";

                        MySqlCommand cmd4 = new MySqlCommand();
                        cmd4.Connection = conn;
                        cmd4.CommandText = sql;

                        using (DbDataReader reader = cmd4.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    rental_id = reader["rental_id"].ToString();
                                    Equip_id = reader["Equip_id"].ToString();
                                    Customer_rent_id = reader["Customer_id"].ToString();
                                    Rental_date = reader["Rental_date"].ToString();
                                    Console.WriteLine("___________________________________________________________");
                                    Console.WriteLine("ID: " + rental_id + " | Iнв-код: " + Equip_id + " | Клiєнт: " + Customer_rent_id + " | Дата: " + Rental_date);
                                    Console.WriteLine("__________________________________________________________");
                                }
                                Console.WriteLine("Головне меню - Enter");
                            }
                        }
                        break;
                    case "6":

                        Console.WriteLine("Таблиця: Sport_еquip");
                        string Equipm_id, Tquip_name, Equip_cost;
                        sql = "select * from Sport_еquip;";

                        MySqlCommand cmd5 = new MySqlCommand();
                        cmd5.Connection = conn;
                        cmd5.CommandText = sql;

                        using (DbDataReader reader = cmd5.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Equipm_id = reader["Equip_id"].ToString();
                                    Tquip_name = reader["Tquip_name"].ToString();
                                    Equip_cost = reader["Equip_cost"].ToString();
                                    Console.WriteLine("_______________________________________");
                                    Console.WriteLine("ID: " + Equipm_id + " | Назва: " + Tquip_name + " | Цiна: " + Equip_cost);
                                    Console.WriteLine("_______________________________________");
                                }
                                Console.WriteLine("Головне меню - Enter");
                            }
                        }
                        break;
                    case "7":

                        Console.WriteLine("Таблиця: Service_Order");
                        string Order_id, Service_ord_id, Customer_ord_id, Order_date;
                        sql = "select * from Service_Order;";

                        MySqlCommand cmd6 = new MySqlCommand();
                        cmd6.Connection = conn;
                        cmd6.CommandText = sql;

                        using (DbDataReader reader = cmd6.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Order_id = reader["Order_id"].ToString();
                                    Service_ord_id = reader["Service_id"].ToString();
                                    Customer_ord_id = reader["Customer_id"].ToString();
                                    Order_date = reader["Order_date"].ToString();
                                    Console.WriteLine("___________________________________________________________");
                                    Console.WriteLine("ID: " + Order_id + " | Посл-код: " + Service_ord_id + " | Клiєнт: " + Customer_ord_id + " | Дата: " + Order_date);
                                    Console.WriteLine("___________________________________________________________");
                                }
                                Console.WriteLine("Головне меню - Enter");
                            }
                        }
                        break;
                    case "8":

                        Console.WriteLine("Таблиця: Services");
                        string Service_id, Serv_name, Serv_cost;
                        sql = "select * from Services;";

                        MySqlCommand cmd7 = new MySqlCommand();
                        cmd7.Connection = conn;
                        cmd7.CommandText = sql;

                        using (DbDataReader reader = cmd7.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Service_id = reader["Service_id"].ToString();
                                    Serv_name = reader["Serv_name"].ToString();
                                    Serv_cost = reader["Serv_cost"].ToString();
                                    Console.WriteLine("_______________________________________");
                                    Console.WriteLine("ID: " + Service_id + " | Назва: " + Serv_name + " | Цiна: " + Serv_cost);
                                    Console.WriteLine("_______________________________________");
                                }
                                Console.WriteLine("Головне меню - Enter");
                            }
                        }
                        break;
                    case "9":
                        Console.WriteLine("Реєстрацiя нового клiєнта");
                        Console.WriteLine("Введiть ID клiєнта (Customer_id):");
                        int insCustId = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введiть П.I.Б. клiєнта (Name):");
                        String insName = Console.ReadLine();
                        Console.WriteLine("Введiть телефон клiєнта (Phone_num):");
                        String insPhone = Console.ReadLine();
                        Console.WriteLine("Введiть ID путiвки (Ticket_id):");
                        int insTickt = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введiть дату заселення (Start_living):");
                        String insLiv = Console.ReadLine();
                        Console.WriteLine("Введiть бронювання кiмнати (Room_order_id):");
                        int insRoomOrdId = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введiть номер кiмнати (Room_id):");
                        int insRoom = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine(insCustId);
                        Console.WriteLine(insName);
                        Console.WriteLine(insPhone);
                        Console.WriteLine(insTickt);
                        Console.WriteLine(insRoomOrdId);

                        Console.WriteLine(insLiv);
                        Console.WriteLine(insRoom);

                        sql = $"USE `Mountain_resort`; INSERT INTO `Mountain_resort`.`Customers` (Customer_id, Name, Phone_num, Ticket_id) VALUES ({insCustId}, '{insName}', '{insPhone}', {insTickt});";

                        MySqlCommand cmd8 = new MySqlCommand();
                        cmd8.Connection = conn;
                        cmd8.CommandText = sql;
                        cmd8.ExecuteNonQuery();

                        sql = $"USE `Mountain_resort`; INSERT INTO `Mountain_resort`.`Hotel` (Room_order_id, Customer_id, Start_living, Room_id) VALUES ({insRoomOrdId}, {insCustId}, '{insLiv}', {insRoom});";

                        MySqlCommand cmd9 = new MySqlCommand();
                        cmd9.Connection = conn;
                        cmd9.CommandText = sql;
                        cmd9.ExecuteNonQuery();

                        break;
                    case "10":
                        Console.WriteLine("Замовлення додаткових послуг");
                        Console.WriteLine("Введiть ID замовлення (Order_id):");
                        int insOrdId = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введiть ID послуги (Service_id):");
                        int insSrvId = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введiть ID клiєнта (Customer_id):");
                        int insCustId3 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введiть дату замовлення (Order_date):");
                        String insOrdDt = Console.ReadLine();
                        Console.WriteLine(insOrdId);
                        Console.WriteLine(insSrvId);
                        Console.WriteLine(insCustId3);
                        Console.WriteLine(insOrdDt);

                        sql = $"USE `Mountain_resort`; " +
                            $"INSERT INTO `Mountain_resort`.`Service_Order` " +
                            $"(Order_id, Service_id, Customer_id, Order_date) " +
                            $"VALUES ({insOrdId}, {insSrvId}, {insCustId3}, '{insOrdDt}');";

                        MySqlCommand cmd10 = new MySqlCommand();
                        cmd10.Connection = conn;
                        cmd10.CommandText = sql;
                        cmd10.ExecuteNonQuery();
                        break;
                    case "11":
                        Console.WriteLine("Оренда спортивного iнвентаря");
                        Console.WriteLine("Введiть ID замовлення (Rental_id):");
                        int insRntId = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введiть ID iнвентаря (Equip_id):");
                        int insEqpId = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введiть ID клiєнта (Customer_id):");
                        int insCustId4 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Введiть дату оренди (Rental_date):");
                        String insRntDt = Console.ReadLine();
                        Console.WriteLine(insRntId);
                        Console.WriteLine(insEqpId);
                        Console.WriteLine(insCustId4);
                        Console.WriteLine(insRntDt);

                        sql = $"USE `Mountain_resort`; INSERT INTO `Mountain_resort`.`Equip_rental` (Rental_id, Equip_id, Customer_id, Rental_date) VALUES ({insRntId}, {insEqpId}, {insCustId4}, '{insRntDt}');";

                        MySqlCommand cmd11 = new MySqlCommand();
                        cmd11.Connection = conn;
                        cmd11.CommandText = sql;
                        cmd11.ExecuteNonQuery();
                        break;
                    default:
                        Console.WriteLine("Невiдома команда");
                        Console.WriteLine("Главное меню - Enter");
                        break;
                    case "12":
                        Console.WriteLine("Вихiд з програми (натиснiть Enter щє раз)");
                        return;
                }
            Console.ReadLine();
            Console.Clear();
            }
        }
    }
}