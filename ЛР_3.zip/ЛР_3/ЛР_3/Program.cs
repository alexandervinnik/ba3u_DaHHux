﻿using MySql.Data.MySqlClient;
using System;
using System.Data.Common;

namespace ЛР_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Getting Connection ...");
            MySqlConnection conn = DBUtils.GetDBConnection();

            try
            {
                Console.WriteLine("Openning Connection ...");
                
                conn.Open();

                Console.WriteLine("Connection Succesful!");
                QueryEmployee(conn);
            }

            catch (Exception e) 
            {
                Console.WriteLine("Error: " + e.Message);
                Console.WriteLine(e.StackTrace);
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
            Console.Read();
        }
        private static void QueryEmployee(MySqlConnection conn)
        {
            string id, num, date, local_p, long_p, p_acc;
            string sql = "select * from payments;";

            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = sql;

            using (DbDataReader reader = cmd.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        id = reader["Payment_id"].ToString();
                        num = reader["Phone_num"].ToString();
                        date = reader["Payment_date"].ToString();
                        local_p = reader["Local_paid"].ToString();
                        long_p = reader["Long_dist_paid"].ToString();
                        p_acc = reader["Paid_account"].ToString();
                        Console.WriteLine("_______________________________________________________________________________________________________________");
                        Console.WriteLine("Код:" + id + " Номер телефона:" + num + " Дата:" + date + " Звонки по городу:" + local_p + " Звонки за город:" + long_p + " Абонетн:" + p_acc);
                        Console.WriteLine("_______________________________________________________________________________________________________________");
                    }
                }
            }
        }
    }
}